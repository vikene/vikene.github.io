improc.js
=========

HTML5 and Javascript based Image processing Library

Example results


<img src="images/gblur.png">
<img src="images/blue.png">
<img src="images/edge.png">
<img src="images/embross.png">
<img src="images/flip.png">
<img src="images/gray.png">
<img src="images/green.png">
<img src="images/invert.png">
<img src="images/red.png">
<img src="images/sharpen.png">
<img src="images/snow.png">